package org.udesa.giftcards.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest
public class GiftCardFacadeTest extends RandomGenerator {
    // Se espera que el usuario pueda inciar sesion con usuario y password y obtener un token
    //    debe poder usar el token para gestionar la tarjeta.
    //    el token se vence a los 5'

    // las giftcards ya estan definidas en el sistema.
    //    el usuario las reclama, pueden ser varias
    //    puede consultar el saldo y el detalle de gastos de sus tarjetas

    // los merchants pueden hacer cargos en las tarjetas que hayan sido reclamadas.
    //    los cargos se actualizan en el balance de las tarjetas
    private static String reservedPrefixTestName = "Bob";
    private static String reservedPassword = reservedPrefixTestName + "Pass";

    @Autowired private GiftCardFacade facade;
    @Autowired private UserService userService;
    @Autowired private GiftCardService giftCardService;
//    @Autowired private MerchantService merchantService;
    @MockBean Clock clock;

    public UserVault aUser;
    public static MerchantVault aMerchant;
    public static GiftCard aGiftCard;

//    public static Random randomStream = new Random( Instant.now( ).getEpochSecond( ) );
//    private int nextKey( ) {
//        return randomStream.nextInt( );
//    }

    private UserVault newSample( ) {
        return new UserVault( newRandomName( reservedPrefixTestName ), reservedPassword );
    }

    private UserVault newSavedSample( ) {
        return userService.save( newSample( ) );
    }

    @BeforeAll public static void beforeAll( @Autowired MerchantService merchantService, @Autowired GiftCardService giftCardService ) {
//        MerchantVault merchantVault =  new MerchantVault( "M1" );
          aMerchant = merchantService.save( newRandomName( "Merchant" ) );
//          aGiftCard = giftCardService.save( newRandomName( "GC" ), 10 );
    }

    @BeforeEach public void beforeEach( ) {
//        facade.reset( );
        when( clock.now( ) ).then( it -> LocalDateTime.now( ) );
        aUser = newSavedSample( );
        aGiftCard = giftCardService.save( newRandomName( "GC" ), 10 ); //que new saved sample reciba dos abstractas!
    }

    @AfterAll public static void afterAll( @Autowired UserService userService, @Autowired MerchantService merchantService, @Autowired GiftCardService giftCardService ) {
        giftCardService.findAll( )
                        .stream( )
                        .filter( giftCard -> giftCard.getName( ).startsWith( "GC" ) )
                        .forEach( giftCardService::delete );

        userService.findAll( )
                .stream( )
                .filter( user -> user.getName( ).startsWith( reservedPrefixTestName ) )
                .forEach( userService::delete );
        merchantService.delete( aMerchant );
//        userService.delete(  );
    }

    @Test public void userCanOpenASession( ) {
        assertNotNull( facade.login( aUser.getName( ), aUser.getPassword( ) ) );
    }

    @Test public void unknownUserCanNotOpenASession( ) {
        assertThrows( RuntimeException.class, ( ) -> facade.login( "Stuart", "StuPass" ) );
    }

    @Test public void userCannotUseAnInvalidtoken( ) {
        assertThrows( RuntimeException.class, ( ) -> facade.redeem( UUID.randomUUID( ),  aGiftCard.getName( ) ) );
        assertThrows( RuntimeException.class, ( ) -> facade.balance( UUID.randomUUID( ),  aGiftCard.getName( ) ) );
        assertThrows( RuntimeException.class, ( ) -> facade.details( UUID.randomUUID( ),  aGiftCard.getName( ) ) );
    }

    @Test public void userCannotCheckOnAlienCard( ) {
        UUID token = facade.login( aUser.getName( ) , aUser.getPassword( ) );
        assertThrows( RuntimeException.class, ( ) -> facade.balance( token,  aGiftCard.getName( ) ) );
    }

    @Test public void userCanRedeemACard( ) {
        UUID token = facade.login( aUser.getName( ), aUser.getPassword( ) );
        facade.redeem( token, aGiftCard.getName( ) );
        assertEquals( 10, facade.balance( token, aGiftCard.getName( ) ) );
    }

    @Test public void userCanRedeemASecondCard( ) {
        UUID token = facade.login( aUser.getName( ), aUser.getPassword( ) );

        GiftCard aGiftCard2 = giftCardService.save( newRandomName( "GC" ), 5 ); //que new saved sample reciba dos abstractas!

        facade.redeem( token, aGiftCard.getName( ) );
        facade.redeem( token, aGiftCard2.getName( ) );

        assertEquals( 10, facade.balance( token, aGiftCard.getName( ) ) );
        assertEquals( 5, facade.balance( token, aGiftCard2.getName( ) ) );
    }

    @Test public void multipleUsersCanRedeemACard( ) {
        UUID aUserToken1 = facade.login( aUser.getName( ), aUser.getPassword( ) );
        UserVault aUser2 = newSavedSample( );
        UUID aUserToken2 = facade.login( aUser2.getName( ), aUser2.getPassword( ) );

        GiftCard aGiftCard2 = giftCardService.save( newRandomName( "GC" ), 5 ); //que new saved sample reciba dos abstractas!


        facade.redeem( aUserToken1, aGiftCard.getName( ) );
        facade.redeem( aUserToken2, aGiftCard2.getName( ) );

        assertEquals( 10, facade.balance( aUserToken1,  aGiftCard.getName( ) ) );
        assertEquals( 5, facade.balance( aUserToken2,  aGiftCard2.getName( ) ) );
    }

    @Test public void unknownMerchantCantCharge( ) {
        assertThrows( RuntimeException.class, ( ) -> facade.charge( "Mx",  aGiftCard.getName( ), 2, "UnCargo" ) );
    }

    @Test public void merchantCantChargeUnredeemedCard( ) {
        assertThrows( RuntimeException.class, ( ) -> facade.charge( aMerchant.getName( ),  aGiftCard.getName( ), 2, "UnCargo" ) );
    }

    @Test public void merchantCanChargeARedeemedCard( ) {
        UUID token = facade.login( aUser.getName( ), aUser.getPassword( ) );

        facade.redeem( token,  aGiftCard.getName( ) );
        facade.charge( aMerchant.getName( ),  aGiftCard.getName( ), 2, "UnCargo" );

        assertEquals( 8, facade.balance( token,  aGiftCard.getName( ) ) );
    }

    @Test public void merchantCannotOverchargeACard( ) {
        UUID token = facade.login( aUser.getName( ), aUser.getPassword( ) );

        facade.redeem( token,  aGiftCard.getName( ) );
        assertThrows( RuntimeException.class, ( ) -> facade.charge( aMerchant.getName( ),  aGiftCard.getName( ), 11, "UnCargo" ) );
    }

    @Test public void userCanCheckHisEmptyCharges( ) {
        UUID token = facade.login( aUser.getName( ), aUser.getPassword( ) );

        facade.redeem( token,  aGiftCard.getName( ) );

        assertTrue( facade.details( token,  aGiftCard.getName( ) ).isEmpty( ) );
    }

    @Test public void userCanCheckHisCharges( ) {
        UUID token = facade.login( aUser.getName( ), aUser.getPassword( ) );

        facade.redeem( token,  aGiftCard.getName( ) );
        facade.charge( aMerchant.getName( ),  aGiftCard.getName( ), 2, "UnCargo" );

        assertEquals( "UnCargo", facade.details( token,  aGiftCard.getName( ) ).getLast() );
    }

    @Test public void userCannotCheckOthersCharges() {
        facade.redeem( facade.login( aUser.getName( ), aUser.getPassword( ) ),  aGiftCard.getName( ) );

        UserVault aUser2 = newSavedSample( );
        UUID token = facade.login( aUser2.getName( ), aUser2.getPassword( ) );

        assertThrows( RuntimeException.class, () -> facade.details( token,  aGiftCard.getName( ) ) );
    }

    @Test public void tokenExpires() {
//        GiftCardFacade facade = newFacade( new Clock( ){
//            Iterator<LocalDateTime> it = List.of( LocalDateTime.now(), LocalDateTime.now().plusMinutes( 16 ) ).iterator();
//            public LocalDateTime now() {
//                return it.next();
//            }
//        } );

        UUID token = facade.login( aUser.getName( ), aUser.getPassword( ) );
        when( clock.now( ) ).then( it -> LocalDateTime.now( ).plusMinutes( 16 ) );
        assertThrows( RuntimeException.class, () -> facade.redeem( token,  aGiftCard.getName( ) ) );
    }

//    private static GiftCardFacade newFacade() {return newFacade( new Clock() );    }
//    private static GiftCardFacade newFacade( Clock  clock ) {
//        return new GiftCardFacade( new ArrayList( List.of( new GiftCard(  aGiftCard.getName( ), 10 ), new GiftCard(  aGiftCard2.getName( ), 5 ) ) ),
////                                  new HashMap( Map.of( aUser.getName( ), aUser.getPassword( ), "Kevin", "KevPass" ) ),
//                                  new ArrayList<>( List.of( aMerchant.getId( ) ) ),
//                                  clock );
//    }

}
