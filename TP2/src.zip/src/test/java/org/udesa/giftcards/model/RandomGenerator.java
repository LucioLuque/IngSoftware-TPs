package org.udesa.giftcards.model;


import java.time.Instant;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class RandomGenerator {

    public static Random randomStream = new Random( Instant.now( ).getEpochSecond( ) );

    public static int nextKey( ) {
        return randomStream.nextInt( ) ;
    }

    public static String newRandomName( String prefix ) {
        return prefix + IntStream.range( 0, 30 - prefix.length( ) )
                .mapToObj( i -> String.valueOf( ( char ) ('A' + Math.abs(nextKey( )) % 26 ) ) )
                .collect( Collectors.joining( ) );
    }

}
