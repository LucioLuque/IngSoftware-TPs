package org.udesa.giftcards.model;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class GiftCardServiceTest extends RandomGenerator {
    private static String reservedPrefixTestName = "Merchant";
    @Autowired protected GiftCardService service;

    @AfterAll public static void afterAll( @Autowired GiftCardService service ) {
        service.findAll( )
                .stream( )
                .filter( giftCard -> giftCard.getName( ).startsWith( reservedPrefixTestName ) )
                .forEach( service::delete );
    }

    protected GiftCard newSample( ) {
        return new GiftCard( newRandomName( reservedPrefixTestName ), 20 );
    }

    protected GiftCard savedSample( ) {
        return service.save( newSample( ) );
    }

    @Test public void testEntitySaveFromString( ) {
        GiftCard retrieved = service.save( newRandomName( reservedPrefixTestName ), 20 );
        assertNotNull( retrieved.getId( ) );
    }

    @Test public void testEntitySave( ) {
        GiftCard model = newSample( );
        GiftCard retrieved = service.save( model );
        assertNotNull( retrieved.getId( ) );
        assertNotNull( model.getId( ) );
        assertEquals( retrieved, model );
    }

//    @Test public void testEntityUpdate( ) {
//        GiftCard model = newSample( );
//
//        updateUser( model );
//        service.save( model );
//        GiftCard retrieved = service.getById( model.getId( ) );
//        assertEquals( model, retrieved );
//    }

    @Test public void testDeletionByObject( ) {
        GiftCard model = savedSample( );

        service.delete( model );
        assertThrows( RuntimeException.class, ( ) -> service.getById( model.getId( ) ) );

    }

    @Test public void testDeletionById( ) {
        GiftCard model = savedSample( );

        service.delete( model.getId( ) );
        assertThrows( RuntimeException.class, ( ) -> service.getById( model.getId( ) ) );
    }

    @Test public void testDeletionByProxy( ) throws Exception {
        GiftCard model = savedSample( );
        GiftCard proxy = model.getClass( ).getConstructor( ).newInstance( );
        proxy.setId( model.getId( ) );

        service.delete( proxy );
        assertThrows( RuntimeException.class, ( ) -> service.getById( model.getId( ) ) );
    }

    @Test public void testFindAll() {
        GiftCard model = savedSample( );
        List list = service.findAll( );
        assertFalse( list.isEmpty( ) );
        assertTrue( list.contains( model ) );
    }
}
