package org.udesa.giftcards.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.udesa.giftcards.model.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
//@DirtiesContext( classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD )
public class ControllerTest extends RandomGenerator {
    @Autowired private MockMvc mockMvc;

//    private String user = "Bob";
//    private String pass = "BobPass";
    @Autowired private UserService userService;
    @Autowired private GiftCardService giftCardService;


    //    private String cardId = "GC1";
    private String baseURL = "/api/giftCards/";

    private static String reservedPrefixTestName = "Bob";
    private static String reservedPassword = reservedPrefixTestName + "Pass";

    public UserVault aUser;
    public static MerchantVault aMerchant;
    public static GiftCard aGiftCard;

//    public static Random randomStream = new Random( Instant.now( ).getEpochSecond( ) );
//    private int nextKey( ) {
//        return randomStream.nextInt( );
//    }

    private UserVault newSample( ) {
        return new UserVault( newRandomName( reservedPrefixTestName ), reservedPassword );
    }

    private UserVault newSavedSample( ) {
        return userService.save( newSample( ) );
    }

    @BeforeEach public void beforeEach( ) {
//        facade.reset( );
//        when( clock.now( ) ).then( it -> LocalDateTime.now( ) );
        aUser = newSavedSample( );
        aGiftCard = giftCardService.save( newRandomName( "GC" ), 10 );
    }

    @BeforeAll public static void beforeAll( @Autowired MerchantService merchantService, @Autowired GiftCardService giftCardService ) {
//        MerchantVault merchantVault =  new MerchantVault( "M1" );
        aMerchant = merchantService.save( newRandomName( "Merchant" ) );
    }

    @AfterAll public static void afterAll( @Autowired UserService userService, @Autowired MerchantService merchantService, @Autowired GiftCardService giftCardService ) {
        giftCardService.findAll( )
                .stream( )
                .filter( giftCard -> giftCard.getName( ).startsWith( "GC" ) )
                .forEach( giftCardService::delete );

        userService.findAll( )
                .stream( )
                .filter( user -> user.getName( ).startsWith( reservedPrefixTestName ) )
                .forEach( userService::delete );
        merchantService.delete( aMerchant );
    }

    @Test void test01LoginSuccess( ) throws Exception {
        assertNotNull( getToken( ) );
    }

    @Test void test02RedeemCard( ) throws Exception {
        String token = getToken( );
        redeem( token );
    }

    @Test void test03CheckBalance( ) throws Exception {
        String token = getToken( );
        redeem( token );
        int balance = getBalance( token );
        assertEquals( 10,  balance );
    }

    @Test void test04CheckEmptyDetails( ) throws Exception {
        String token = getToken( );
        redeem( token );
        List<String> details = getDetails( token );
        assertTrue( details.isEmpty( ) );
    }

    @Test void test05CheckChargesDetails( ) throws Exception {
        String token = getToken( );
        redeem( token );
        charge( aMerchant.getName( ), 2, "UnCargo");
        List<String> details = getDetails( token );
        assertEquals( "UnCargo", details.getLast( ) );
    }

    private void charge( String merchant, int amount, String description ) throws Exception {
        mockMvc.perform( post( baseURL + aGiftCard.getName( ) + "/charge" )
                        .param( "merchant", merchant )
                        .param( "amount", String.valueOf( amount ) )
                        .param( "description", description )
                        .contentType( MediaType.APPLICATION_JSON ) )
                .andDo( print( ) )
                .andExpect( status( ).is( 200 ) );
    }

    private List<String> getDetails( String token ) throws Exception {
        return  new ObjectMapper( ).readValue(
                mockMvc.perform( get( baseURL + aGiftCard.getName( ) + "/details")
                        .header( "Authorization", "Bearer " + token ) )
                        .andDo( print( ) )
                        .andExpect( status( ).is( 200 ) )
                        .andReturn( )
                        .getResponse( )
                        .getContentAsString( ), new TypeReference<Map<String, List<String>>>( ) { } ).get( "details" );
    }

    private int getBalance( String token ) throws Exception {
        return (Integer) new ObjectMapper( ).readValue(
                mockMvc.perform( get( baseURL + aGiftCard.getName( ) + "/balance" )
                                .header( "Authorization", "Bearer " + token ) )
                        .andExpect( status( ).isOk( ) )
                        .andReturn( )
                        .getResponse( )
                        .getContentAsString( ), HashMap.class ).get( "balance" );
    }

    private void redeem( String token )throws Exception {
          mockMvc.perform( post( baseURL + aGiftCard.getName( ) + "/redeem" )
                          .header( "Authorization", "Bearer " + token )
                        .contentType( MediaType.APPLICATION_JSON ) )
                .andDo( print( ) )
                .andExpect( status( ).is( 200 ) );
    }

    private String getToken( ) throws Exception {
        return  (String) new ObjectMapper(  )
                .readValue( mockMvc.perform( post( baseURL + "login" )
                                                .param( "user", aUser.getName( ) )
                                                .param( "pass", aUser.getPassword( ) ) )
                                    .andExpect( status( ).is( 200 ) )
                                    .andExpect( content( ).string( containsString ( "token" ) ) )
                                    .andReturn( )
                                    .getResponse( )
                                    .getContentAsString( ),
                            HashMap.class ).get( "token" );
    }
}
