package org.udesa.giftcards.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter @Setter
public class GiftCard {
    @GeneratedValue( strategy = GenerationType.IDENTITY )
    @Id private long id;

    @Column( unique = true) private String name;
    @Column private int balance;

    @ManyToOne( )
    @JoinColumn( name = "owner_id" )
    private UserVault owner;

    @OneToMany( mappedBy ="giftCard", cascade = CascadeType.ALL, orphanRemoval = true ,fetch = FetchType.EAGER)
    @Column private List<Charge> charges = new ArrayList<>();

//    @Id private String id;
//    @Column private int balance;
//    @Column private Long ownerId;
//    @Column private List<String> charges = new ArrayList<>();

    public GiftCard( ) { }

    public GiftCard( String name, int initialBalance) {
//        this.id = name;
        this.name = name;
        this.balance = initialBalance;
    }

    public boolean equals( Object o ) {
        return this == o ||
                o != null && id != 0 &&
                        getClass( ) == o.getClass( ) && id == getClass( ).cast( o ).getId( ) &&
                        same( o );
    }

    public int hashCode( ) {
        return Long.hashCode( id );
    }

    protected boolean same( Object o ) {
        return name.equals( getClass( ).cast(  o ).getName( ) );
    }


//    public boolean equals( Object o ) {
//        return this == o ||
//                o != null  &&
//                        getClass( ) == o.getClass( ) && id == getClass( ).cast( o ).getId( ) &&
//                        same( o );
//    }
//
//    public int hashCode( ) {
//        return id.hashCode( );
//    }
//
//    protected boolean same( Object o ) {
//        return id.equals( getClass( ).cast(  o ).getId( ) );
//    }
}
