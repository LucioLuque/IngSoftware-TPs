package org.udesa.giftcards.model;

import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface GiftCardRepository extends CrudRepository<GiftCard, Long> {

    Optional<GiftCard> findByName( String name );
}
