package org.udesa.giftcards.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@Entity
public class UserVault {
    @GeneratedValue( strategy = GenerationType.IDENTITY )
    @Id private long id;
    @Column( unique = true) private String name;
    @Column private String password;

    public UserVault( ) { }

    public UserVault( String name, String password ) {
        this.name = name;
        this.password = password;
    }

    public boolean equals( Object o ) {
        return this == o ||
                o != null && id != 0 &&
                        getClass( ) == o.getClass( ) && id == getClass( ).cast( o ).getId( ) &&
                        same( o );
    }

    public int hashCode( ) {
        return Long.hashCode( id );
    }

    protected boolean same( Object o ) {
        return name.equals( getClass( ).cast(  o ).getName( ) );
    }
}
