package org.udesa.giftcards.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.udesa.giftcards.model.GiftCardFacade;

import java.util.*;


@RestController
@RequestMapping("/api/giftCards/")
public class GiftCardController {
    @Autowired GiftCardFacade giftCardFacade;
//    @ExceptionHandler( RuntimeException.class )
//    public ResponseEntity<String> handleIllegalArgument( RuntimeException ex ) {
//        return ResponseEntity.internalServerError( ).body( ex.getMessage( ) );
//    }

//    private GiftCardFacade giftCardFacade = newFacade( );

//    private GiftCardFacade newFacade( ) {
//        return newFacade( );
//    }

//    private GiftCardFacade newFacade( ) {
//        return new GiftCardFacade( new ArrayList( List.of( new GiftCard( "GC1", 10 ), new GiftCard( "GC2", 5 ) ) ),
////                new HashMap( Map.of( "Bob", "BobPass", "Kevin", "KevPass" ) ),
//                new ArrayList<>( List.of( "M1" ) ) );
//    }

    private UUID getToken( String header ) {
        String tokenHeader = header.trim( );

        if ( tokenHeader.startsWith( "Bearer " ) ) {
            tokenHeader = tokenHeader.substring( 7 ).trim( );
        }

        return UUID.fromString( tokenHeader );
    }

    @PostMapping( value = "login", params = {"user", "pass"} )
    public ResponseEntity<Map<String, Object>> login( @RequestParam String user, @RequestParam String pass ) {
        return ResponseEntity.ok( Map.of( "token", giftCardFacade.login( user, pass ).toString( ) ) );
    }

    @PostMapping( value = "{cardId}/redeem" )
    public ResponseEntity<String> redeem( @RequestHeader( "Authorization" ) String header, @PathVariable String cardId ) {
        giftCardFacade.redeem( getToken( header ), cardId );
        return ResponseEntity.ok( ).build( );
    }

    @GetMapping( "{cardId}/balance" )
    public ResponseEntity<Map<String, Object>> balance( @RequestHeader( "Authorization" ) String header, @PathVariable String cardId ) {
        return ResponseEntity.ok( Map.of( "balance", giftCardFacade.balance( getToken( header ), cardId ) ) );
    }

    @GetMapping( "{cardId}/details" )
    public ResponseEntity<Map<String, Object>> details( @RequestHeader( "Authorization" ) String header, @PathVariable String cardId ) {
        return ResponseEntity.ok( Map.of( "details", giftCardFacade.details( getToken( header ), cardId ) ) );
    }

    @PostMapping("{cardId}/charge")
    public ResponseEntity<String> charge( @RequestParam String merchant, @RequestParam int amount, @RequestParam String description, @PathVariable String cardId ) {
        giftCardFacade.charge( merchant, cardId, amount, description );
        return ResponseEntity.ok( ).build( );
    }

}
