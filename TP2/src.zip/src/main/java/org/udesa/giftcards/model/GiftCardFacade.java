package org.udesa.giftcards.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class GiftCardFacade {
    public static final String InvalidUser = "InvalidUser";
    public static final String InvalidMerchant = "InvalidMerchant";
    public static final String InvalidToken = "InvalidToken";

//    private Map<String, GiftCard> cards;
//    private List<String>  merchants;

    @Autowired private UserService userService;
    @Autowired private MerchantService merchantService;
    @Autowired private GiftCardService giftCardService;
    @Autowired private Clock clock;

    private Map<UUID, UserSession> sessions = new HashMap( );

    public GiftCardFacade( ) {
//        List<GiftCard> cards = new ArrayList( List.of( new GiftCard( "GC1", 10 ), new GiftCard( "GC2", 5 ) ) );
//        this.cards = cards.stream().collect( Collectors.toMap( each -> each.id(), each -> each ));
//        this.merchants = List.of("M1");
    }

//    public GiftCardFacade( List<GiftCard> cards ) {
//        this.cards = cards.stream().collect( Collectors.toMap( each -> each.id(), each -> each ));
////        this.merchants = merchants;
//    }

    public UUID login( String userKey, String pass ) {

        userService.validateUser( userKey, pass );
//        if ( !pass.equals( userService.findByName( userKey ).getPassword( ) ) ) throw new RuntimeException(  InvalidUser );


//        if ( !users.computeIfAbsent( userKey, key -> { throw new RuntimeException( InvalidUser ); } )
//                .equals( pass ) ) {
//            throw new RuntimeException( InvalidUser );
//        }

        UUID token = UUID.randomUUID( );
        sessions.put( token, new UserSession( userKey, clock ) );
        return token;
    }

    public void redeem( UUID token, String cardName ) {
        giftCardService.redeem( cardName, findUser( token ) );
    }

    public int balance( UUID token, String cardId ) {
        return giftCardService.balance( ownedCard( token, cardId ) );
//        return ownedCard( token, cardId ).balance();
    }

    public void charge( String merchantKey, String cardId, int amount, String description ) {
        if ( !merchantService.contains( merchantKey ) ) throw new RuntimeException( InvalidMerchant );
        giftCardService.charge( cardId, amount, description );
//        cards.get( cardId ).charge( amount, description );
    }

    public List<String> details( UUID token, String cardId ) {
        return giftCardService.details( ownedCard( token, cardId ) );
//        return ownedCard( token, cardId ).charges();
    }

    private GiftCard ownedCard( UUID token, String cardName ) {
//        GiftCard card = cards.get( cardId );
        GiftCard card = giftCardService.getByName( cardName );
        if ( !giftCardService.cardIsOwnedBy( card, findUser( token ) ) ) throw new RuntimeException( InvalidToken );
//        if ( !card.isOwnedBy( findUser( token ) ) ) throw new RuntimeException( InvalidToken );
        return card;
    }

    private String findUser( UUID token ) {
        return sessions.computeIfAbsent( token, key -> { throw new RuntimeException( InvalidToken ); } )
                       .userAliveAt( clock );
    }
//
//    public void reset( ) {
//        cards.values( ).stream( ).forEach( GiftCard::reset );
//        sessions.clear( );
//    }
}
