package org.udesa.giftcards.model;

import org.springframework.data.repository.CrudRepository;

public interface MerchantRepository extends CrudRepository<MerchantVault, Long> {
//    Long getByName( String name );

    MerchantVault findByName( String name );
}
