package org.udesa.giftcards.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.function.Supplier;
import java.util.stream.StreamSupport;

@Service
public class GiftCardService {
    public static final String CargoImposible = "CargoImposible";
    public static final String InvalidCard = "InvalidCard";

    @Autowired private GiftCardRepository giftCardRepository;
//    @Autowired private UserRepository userRepository;

    @Autowired private UserService userService;

    @Transactional( readOnly = true )
    public List<GiftCard> findAll( ) {
        return StreamSupport.stream( giftCardRepository.findAll( ).spliterator( ), false ).toList( );
    }

    @Transactional( readOnly = true )
    public GiftCard getById( long id, Supplier<? extends GiftCard> supplier ) {
        return giftCardRepository.findById( id ).orElseGet( supplier );
    }

    public GiftCard getById( long id ) {
        return getById( id, ( ) -> {
            throw new RuntimeException( "Object of class " + GiftCard.class + " and id: " + id + " not found" );
        } );
    }

    @Transactional( readOnly = true )
    public GiftCard getByName( String name, Supplier<? extends GiftCard> supplier ) {
        return giftCardRepository.findByName( name ).orElseGet( supplier );
    }

    public GiftCard getByName( String name ) {
        return getByName( name, ( ) -> {
            throw new RuntimeException( "Object of class " + GiftCard.class + " and name: " + name + " not found" );
        } );
    }

    public GiftCard save( GiftCard model ){
        return giftCardRepository.save( model );
    }

    public GiftCard save( String name, int initialBalance ){
        return giftCardRepository.save( new GiftCard( name, initialBalance ) );
    }

    public void delete( long id ) {
        giftCardRepository.deleteById( id );
    }

    public void delete( GiftCard model ) {
        giftCardRepository.delete( model );
    }

    public boolean contains( long id ) {
        return giftCardRepository.existsById( id );
    }

    @Transactional
    public GiftCard charge( GiftCard model, int anAmount, String description ) {
        if ( !owned( model ) || model.getBalance( ) - anAmount < 0 )  throw new RuntimeException( CargoImposible );
        model.setBalance( model.getBalance( ) - anAmount );
        model.getCharges( ).add( description );
        return model;
    }

    @Transactional
    public GiftCard charge( String name, int anAmount, String description ) {
        return charge( getByName( name ), anAmount, description );
    }

    private static boolean owned( GiftCard model ) {
        return model.getOwner( ) != null;
    }

    @Transactional
    public GiftCard redeem( GiftCard model, String newOwner ) {
        if ( owned( model ) ) throw new RuntimeException( InvalidCard );
        model.setOwner( userService.findByName( newOwner ) );
        return model;
    }

    @Transactional
    public GiftCard redeem( String name, String newOwner ) {
        return redeem( getByName( name ), newOwner );
    }

//    public int balance( String cardId, String user ) {
//
//    }

    public boolean cardIsOwnedBy( GiftCard card, String user ) {
        return card.getOwner( ).getId( ) == userService.findByName( user ).getId( );
    }

    public int balance( GiftCard model ) {
        return model.getBalance( );
    }

    public List<String> details( GiftCard model ) {
        return model.getCharges( );
    }
}
