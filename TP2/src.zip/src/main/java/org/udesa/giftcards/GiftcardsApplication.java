package org.udesa.giftcards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiftcardsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiftcardsApplication.class, args);
	}

}
