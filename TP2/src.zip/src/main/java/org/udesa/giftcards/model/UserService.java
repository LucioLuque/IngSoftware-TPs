package org.udesa.giftcards.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.function.Supplier;
import java.util.stream.StreamSupport;

@Service
public class UserService {
    @Autowired private UserRepository repository;

    @Transactional( readOnly = true )
    public List<UserVault> findAll( ) {
        return StreamSupport.stream( repository.findAll( ).spliterator( ), false ).toList( );
    }

    @Transactional( readOnly = true )
    public UserVault getById( long id, Supplier<? extends UserVault > supplier ) {
        return repository.findById( id ).orElseGet( supplier );
    }

    public UserVault getById( long id ) {
        return getById( id, ( ) -> {
            throw new RuntimeException( "Object of class " + UserVault.class + " and id: " + id + " not found" );
        } );
    }

    public UserVault save( UserVault model ){
        return repository.save( model );
    }

    public UserVault update( Long id, UserVault updatedObject ) {
        UserVault object = getById( id );
        updateData( object, updatedObject );
        return save( object );
    }

    @Transactional( readOnly = true )
    public long count( ) {
        return repository.count( );
    }

    protected void updateData( UserVault existingObject, UserVault updatedObject ) {
        existingObject.setName( updatedObject.getName( ) );
        existingObject.setPassword( updatedObject.getPassword( ) );
    }

    public void delete( long id ) {
        repository.deleteById( id );
    }

    public void delete( UserVault model ) {
        repository.delete( model );
    }

    public UserVault findByName( String userName ) {
        return repository.findByName( userName ).orElseThrow( ( ) -> new RuntimeException( GiftCardFacade.InvalidUser ) );
    }

    public void validateUser(String userName, String password) {
        repository.findByName( userName )
                .filter( u -> u.getPassword( ).equals( password ) )
                .orElseThrow( ( ) -> new RuntimeException( GiftCardFacade.InvalidUser ) );
    }

}