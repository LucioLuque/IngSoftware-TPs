package org.udesa.giftcards.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.function.Supplier;
import java.util.stream.StreamSupport;

@Service
public class MerchantService {
    @Autowired private MerchantRepository repository;

    @Transactional( readOnly = true )
    public List<MerchantVault> findAll( ) {
        return StreamSupport.stream( repository.findAll( ).spliterator( ), false ).toList( );
    }

    @Transactional( readOnly = true )
    public MerchantVault getById( long id, Supplier<? extends MerchantVault > supplier ) {
        return repository.findById( id ).orElseGet( supplier );
    }

    public MerchantVault getById( long id ) {
        return getById( id, ( ) -> {
            throw new RuntimeException( "Object of class " + MerchantVault.class + " and id: " + id + " not found" );
        } );
    }

    public MerchantVault save( MerchantVault model ){
        return repository.save( model );
    }

    public MerchantVault save( String name ){
        return repository.save( new  MerchantVault( name ) );
    }

//    public MerchantVault update( String id, MerchantVault updatedObject ) {
//        MerchantVault object = getById( id );
//        updateData( object, updatedObject );
//        return save( object );
//    }

    @Transactional( readOnly = true )
    public long count( ) {
        return repository.count( );
    }

//    protected void updateData( MerchantVault existingObject, MerchantVault updatedObject ) {
//        existingObject.setName( updatedObject.getName( ) );
//        existingObject.setPassword( updatedObject.getPassword( ) );
//    }

    public void delete( long id ) {
        repository.deleteById( id );
    }

    public void delete( MerchantVault model ) {
        repository.delete( model );
    }

//    public boolean contains( long id ) {
//        return repository.existsById( id );
//    }

    public boolean contains( String name ) {
        return repository.existsById( idByName( name ) );
    }

    public long idByName( String name ) {
        return repository.findByName( name ).getId( );
//        return repository.findByName( userName ).orElseThrow( ( ) -> new RuntimeException( GiftCardFacade.InvalidUser ) );
    }

}
