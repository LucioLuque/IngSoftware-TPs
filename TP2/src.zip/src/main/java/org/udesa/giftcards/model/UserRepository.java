package org.udesa.giftcards.model;

import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserRepository extends CrudRepository<UserVault, Long> {
    Optional<UserVault> findByName( String userName );

    Long getByName( String name );

//    Optional<UserVault> findByPassword( String password );
//
//    Optional<UserVault> findById( Long id );
//
//    Optional<UserVault> findAllById( Iterable<Long> longs );
}
